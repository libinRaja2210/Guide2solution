<?php
include('config.php');
require('fpdf/fpdf.php');
$id= $_GET['id'];
$Name=$_GET['Name'];
//A4 width : 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm

$pdf = new FPDF('P','mm','A4');

$pdf->AddPage();

//Image( file name , x position , y position , width [optional] , height [optional] )
$pdf->Image('G2S.png',30,5,24,20);


//set font to arial, bold, 14pt
$pdf->SetFont('Arial','B',14);



//Cell(width , height , text , border , end line , [align] )

$pdf->Cell(200	,5,'VISITOR OF TOURIST,',0,0,'C');

//set font to arial, regular, 12pt
$pdf->SetFont('Arial','',12);

$pdf->Cell(130	,5,'',0,0);
$pdf->Cell(59	,5,'',0,1);//end of line
$pdf->Cell(200	,5,'DEPARTMENT OF TOURIST',0,0,'C');

$query=mysqli_query($con,"SELECT * FROM print_datatable WHERE id='$id'");
        while($row=mysqli_fetch_array($query)){
$pdf->Cell(189	,10,'',0,1);//end of line
$pdf->Cell(170   ,10,'Date :',0,0,'R');
$pdf->Cell(59	,10,$row['date'],0,1);//end of line

$pdf->Cell(170	,10,'No :',0,0,'R');
$pdf->Cell(59	,10,$row['id'],0,1);//end of line


//make a dummy empty cell as a vertical spacer

//billing address


$pdf->SetFont('Arial','B',12);
$pdf->Cell(100	,5,'Visitor Of Tourism',0,1);//end of line
$pdf->Cell(100	,5,'',0,1);//end of line


$pdf->SetFont('Arial','B',10);
$pdf->Cell(45	,5,'Name',0,0);
$pdf->SetFont('Arial','I',10);
$pdf->Cell(90	,5, $row['Name'],0,1);
$pdf->Cell(100	,2,'',0,1);//end of line


$pdf->SetFont('Arial','B',10);
$pdf->Cell(45	,5,'Gender',0,0);
$pdf->SetFont('Arial','I',10);
$pdf->Cell(90	,5,$row['Gender'],0,1);
$pdf->Cell(100	,2,'',0,1);//end of line


$pdf->SetFont('Arial','B',10);
$pdf->Cell(45	,5,'Country',0,0);
$pdf->SetFont('Arial','I',10);
$pdf->Cell(90	,5,$row['Country'],0,1);
$pdf->Cell(100	,2,'',0,1);//end of line


$pdf->Cell(189	,10,'',0,1);//end of line
$pdf->SetFont('Arial','B',10);

$pdf->Cell(130	,4,'PRESBYTER',0,0);
$pdf->Cell(59	,5,'COMMITTEE MEMBER',0,1);//end of line


//make a dummy empty cell as a vertical spacer
//$pdf->Cell(289	,20,'',0,1);//end of line

//set font to arial, bold, 14pt
//$pdf->SetFont('Arial','B',10);

//$gambar=$row['checkFile'];

//$pdf->Image('imgcheck/' . $gambar,140,200,50,30);


//$pdf->Cell(59	,5,'Approve',0,1);//end of line
//$pdf->Cell(300	,5,'Approve',0,1);//end of line


}

$pdf->Output("Laporan Check.pdf","I");
?>
