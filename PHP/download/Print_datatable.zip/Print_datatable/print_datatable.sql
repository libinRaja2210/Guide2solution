CREATE TABLE IF NOT EXISTS `print_datatable` (
 `id` int(11) NOT NULL ,
 `Name` varchar(50) NOT NULL,
 `Gender` varchar(50) NOT NULL,
`Country` varchar(50) NOT NULL,
 `date` date NOT NULL
 );
ALTER TABLE `print_datatable`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `print_datatable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

INSERT INTO `print_datatable` (`id`, `Name`, `Gender`, `Country`, `date`) VALUES
(1, 'Antoni','male','India', '2019-06-05'),
(2, 'Martin','male','America', '2019-05-15'),
(3, 'Arul','male','London', '2019-05-06'),
(4, 'Libin','male','China', '2019-06-02'),
(5, 'Austin','male','Pakistan', '2019-05-25'),
(6, 'Lefia','female','India', '2019-03-22'),
(7, 'Agastin','male','srilanka', '2019-05-05');
