<!DOCTYPE html>
<html>
<head>
  <style>
  #customers {
  
  border-collapse: collapse;
  width: 94%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 6px;
  color: green;
  font-weight:bold;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  margin-left: 10px;
  text-align: left;
  background-color: #ff33ff;
  color: white;
}
  </style>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

  
</head>
<body>
<form method="post" action="">
 <div class="box box-info" >
<br>
   <div class="table-responsive">
   <br>
	<table id="customers" border="1" align="center">
	<thead>
		<tr>
			 <th style="text-align:center;">No</th>
		   <th style="text-align:center;">Name</th>
		   <th style="text-align:center;">Gender</th>
       		   <th style="text-align:center;">Country</th>
			   <th style="text-align:center;">Date</th>
			   <th style="text-align:center;">Print</th>
       		   
		</tr>
	</thead>
	<tbody>
	<?php 
	include('config1.php');
	$query=mysqli_query($con,"SELECT * FROM print_datatable order by id ASC");
              $cnt=1;
              while($row=mysqli_fetch_array($query))
              {
                ?>                
			<tr>
                  <td style="text-align:center;"><?php echo $row['id']; ?></td>
<td style="text-align:center;"><?php echo $row['Name']; ?></td>
<td style="text-align:center;"><?php echo $row['Gender']; ?></td>
<td style="text-align:center;"><?php echo $row['Country']; ?></td>
<td style="text-align:center;"><?php echo $row['date']; ?></td>

                  <td style="text-align:center;">
                    <a href="print.php?id=<?php echo htmlentities($row['id']);?>&Name=<?php echo htmlentities($row['Name']);?>"><button type="button" class="btn btn-success">Print</button></a>
                  </td>
                </tr>

              <?php  } ?>
	<tbody>
	<tfoot>
	<tr>
			<th style="text-align:center;">No</th>
		   <th style="text-align:center;">Name</th>
		   <th style="text-align:center;">Gender</th>
       		   <th style="text-align:center;">Country</th>
			   <th style="text-align:center;">Date</th>
			   <th style="text-align:center;">Print</th>
		</tr>
	</tfoot>
	<script>
$(document).ready(function() {
    $('#customers').DataTable( {
        "paging":   true,
        "ordering": true,
        "info":     true
    } );
} );
</script> 
	</table>
   </div>
  </div>
  </form>
 </body>
</html>
