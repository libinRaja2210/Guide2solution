<!DOCTYPE html>
<html>
<head>

<style>
	#mytable{
display:none;
   
}
.dataTables_length {
	width: 100%;

}

.dataTables_info {
	width: 100%;
}


table.jambo_table thead tr:first-child{
	background: #f44141;
	color: white;
	font-weight:bold;
	width: 100%;
}
table.jambo_table tfoot tr:first-child{
	background: #f44141;
	color: white;
	font-weight:bold;
}
table.jambo_table td {
	color: green;
	font-weight:bold;
}

table a{

	color:#1ABB9C;
}

table.display {

	width: 100% !important;
}    


tfoot input {
	 margin: 0; 

}
tfoot .form-control{
    font-size:0;
}


table.jambo_table thead tr:last-child{
	background: white;
}


.dt-buttons{
    margin-right:20px;
	margin-left:20px;
}

.dataTables_filter input{
    font-weight:bold;
}

div.dataTables_filter input {
	margin-left: 0 !important;

}
  </style>
  
  <script type="text/javascript" src="https://cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />

  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  
  <script src="https://cdn.datatables.net/v/bs-3.3.7/jq-2.2.4/dt-1.10.15/datatables.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
	 <link rel="stylesheet" href="https://cdn.datatables.net/v/bs-3.3.7/jq-2.2.4/dt-1.10.15/datatables.min.css" />
    <!-- Include Date Range Picker -->
<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.2.0/js/dataTables.buttons.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.2.0/js/buttons.bootstrap.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.2.0/js/buttons.html5.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.2.0/js/buttons.print.min.js">
	</script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.2.0/js/buttons.colVis.min.js">
	</script>
  
  <script type="text/javascript" src="https://cdn.datatables.net/colreorder/1.3.2/js/dataTables.colReorder.min.js"></script>

  </head>
  <body>
  <div class="box box-info">
<br>
  <div class="container">
  <div class="form-row">
  <div class="col-md-4">
  </div>
   <div class="col-md-4">
  </div>
  <div class="col-md-3">
    <div class="input-group input-daterange">

      <input type="text" id="min-date" class="form-control date-range-filter" data-date-format="yyyy-mm-dd" placeholder="From:">

      <div class="input-group-addon">to</div>

      <input type="text" id="max-date" class="form-control date-range-filter" data-date-format="yyyy-mm-dd" placeholder="To:">

    </div>
  </div>
</div>
</div>
<div class="table-responsive">
<table id="mytable" class="table display table-striped responsive-utilities jambo_table">
 

<thead>

       <tr>
		<th style="text-align:center;">Income ID</th>
       		<th style="text-align:center;">Name</th>
       		<th style="text-align:center;">Date</th>
       		<th style="text-align:center;">Amount</th>       		
	    </tr>


    <tr class="filters" >
       <th class="input-filter">
            Income ID
        </th>
       
        <th class="input-filter">
            Name
        </th>

        <th class="input-filter">
            Date
        </th>
         <th class="input-filter">
            Amount
        </th>        

        <th></th>
    </tr>
    </thead>
    <tbody>
		<?php
include('conn.php');
$result = $db->prepare("SELECT * FROM `datatable`");
$result->execute();
for($i=0; $row = $result->fetch(); $i++)

{
?>
<tr>
<td style="text-align:center;"><?php echo $row['id']; ?></td>
<td style="text-align:center;"><?php echo $row['name']; ?></td>
<td style="text-align:center;"><?php echo $row['date']; ?></td>
<td style="text-align:center;"><?php echo $row['amount']; ?></td>

 <td>

                    <div class="dropdown">
                        
                    </div>


                </td>
</tr>
<?php
}
?>
	</tbody>
       <tfoot>
            <tr>
		<th style="text-align:center;">Income ID</th>
       		<th style="text-align:center;">Name</th>
       		<th style="text-align:center;">Date</th>
       		<th style="text-align:center;">Amount</th>
	    </tr>
        </tfoot>
</table>
</div>
</div>
<script type="text/javascript">
	$(function () {
     


       $('#mytable thead tr.filters th').each(function () {
           var title = $(this).text();


           if ($(this).hasClass("input-filter")) {


               $(this).html('<input name ="' + $.trim(title).replace(/ /g, '') + '" type="text" class = "form-control" placeholder="Search ' + $.trim(title) + '" />');
			   $("#mytable thead input").on( 'keyup change', function () {
        table
            .column( $(this).parent().index()+':visible' )
            .search( this.value )
            .draw();
    } );
           }
           else if ($(this).hasClass("date-filter")) {

               $(this).html('<div class="input-prepend input-group"><span class="add-on input-group-addon"><i class="glyphicon glyphicon-calendar fa fa-calendar"></i></span><input type="text" style="width: 200px" name="' + $.trim(title).replace(/ /g, '') + '"  placeholder="Search ' + $.trim(title) + '" class="form-control daterange"/></div>');

           }

       });

           

        // DataTable
        var table = $("#mytable").DataTable({
                     
            dom: "rBftlip",

            buttons: [
            {
                extend: 'collection',
                text: 'Export',
                buttons:
                    [
                               
                        {
                            extend: "copy",
                            exportOptions: { columns: ':visible:not(:first-child)' }, //last column has the action types detail/edit/delete
                            footer:true
                        },
                        {
                            extend: "csv",
                            exportOptions: { columns: ':visible:not(:first-child)' },
                            footer: true
                        },
                        {
                            extend: "excel",
                            exportOptions: { columns: ':visible:not(:first-child)' },
                            footer:true
                        },
                        {
                            extend: "pdf",
                            exportOptions: { columns: ':visible:not(:first-child)' },
                            footer:true
                        },
                        {
                            extend: "print",
                            exportOptions: { columns: ':visible:not(:first-child)' },
                            footer: true
                        }

                    ]
            }
            ],
           
            responsive: true,
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            orderCellsTop: true,
            scrollX: true,
            colReorder: true,
                    

           
                   
            processing: true,


            "initComplete": function (settings, json) {
                //  $("#mytable_processing").css("visibility", "hidden");
                $('#mytable').fadeIn();
            },
                

          
            "footerCallback": function( tfoot, data, start, end, display ) {             
			var api = this.api();
				nb_cols = api.columns().nodes().length;
				var j = 3;
				while(j < nb_cols){
					var pageTotal = api
                .column( j, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return Number(a) + Number(b);
                }, 0 );
          // Update footer
          $( api.column( j ).footer() ).html('₹'+pageTotal);
					j++;
				} 
		                    
            },
          
        });

        new $.fn.dataTable.Buttons(table, {
            buttons: [
              {
                  extend: 'colvis',
                  text: 'Show/Hide Columns'

              },

            ]
        });

        //add button to top
        table.buttons(0, null).container().prependTo(
              table.table().container()
          );
                

        //remove class from search filter
        ($("#mytable_filter input").removeClass("input-sm"));



      

        //instantiate datepicker and choose your format of the dates
        $('.input-daterange input').each(function() {
  $(this).datepicker('clearDates');
});


// Extend dataTables search
$.fn.dataTable.ext.search.push(
  function(settings, data, dataIndex) {
    var min = $('#min-date').val();
    var max = $('#max-date').val();
    var createdAt = data[2] || 0; // Our date column in the table

    if (
      (min == "" || max == "") ||
      (moment(createdAt).isSameOrAfter(min) && moment(createdAt).isSameOrBefore(max))
    ) {
      return true;
    }
    return false;
  }
);

// Re-draw the table when the a date range filter changes
$('.date-range-filter').change(function() {
  table.draw();
});

$('#mytable_filter').hide();
       
           
        //hide unnecessary columns
        var column = table.columns($('.HideColumn'));
        // Toggle the visibility
        column.visible(!column.visible());

        // Apply the search
        $.each($('.input-filter', table.table().header()), function () {
            var column = table.column($(this).index());
            //onsole.log(column);
            $('input', this).on('keyup change', function () {
                if (column.search() !== this.value) {
                    column
                        .search(this.value)
                        .draw();
                }
            });
        });
       

    
         

    });

</script>

</body>
</html>