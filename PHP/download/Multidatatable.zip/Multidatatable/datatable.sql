CREATE TABLE IF NOT EXISTS `datatable` (
 `id` int(11) NOT NULL ,
 `name` varchar(50) NOT NULL,
 `date` date NOT NULL,
 `amount` double(12,2) NOT NULL
 );
ALTER TABLE `datatable`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `datatable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

INSERT INTO `datatable` (`id`, `name`, `date`, `amount`) VALUES
(1, 'Antoni', '2019-06-05', '10500'),
(2, 'Martin', '2019-05-15', '12500'),
(3, 'Arul', '2019-05-06', '11200'),
(4, 'Libin', '2019-06-02', '14200'),
(5, 'Austin', '2019-05-25', '10500'),
(6, 'Lefia', '2019-03-22', '7500'),
(7, 'Anu', '2019-04-07', '17200'),
(8, 'Mary', '2019-05-15', '10500'),
(9, 'Xavier', '2019-06-09', '11800'),
(10, 'Francis', '2019-06-06', '13100'),
(11, 'Agastin', '2019-05-05', '10500');